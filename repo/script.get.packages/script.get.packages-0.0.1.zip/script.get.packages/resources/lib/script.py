# -*- coding: utf-8 -*-

import io, os, sys, time, zipfile, urllib.request, logging, xbmc, xbmcaddon, xbmcgui, xbmcvfs
from resources.lib import kodiutils
#from resources.lib import kodilogging


ADDON = xbmcaddon.Addon()
#logger = logging.getLogger(ADDON.getAddonInfo('id'))


class Canceled(Exception):
    pass


class MyProgressDialog():
    def __init__(self, process):
        self.dp = xbmcgui.DialogProgress()
        self.dp.create("MastaaaTV", process)

    def __call__(self, block_num, block_size, total_size):
        if self.dp.iscanceled():
            self.dp.close()
            raise Canceled
        percent = (block_num * block_size * 100) / total_size
        if percent < total_size:
            self.dp.update(int(percent))
        else:
            self.dp.close()


def read(response, progress_dialog):
    data = b""
    total_size = response.getheader('Content-Length').strip()
    total_size = int(total_size)
    bytes_so_far = 0
    chunk_size = 1024 * 1024
    reader = lambda: response.read(chunk_size)
    for index, chunk in enumerate(iter(reader, b"")):
        data += chunk
        progress_dialog(index, chunk_size, total_size)
    return data


def extract(zip_file, output_directory, progress_dialog):
    zin = zipfile.ZipFile(zip_file)
    files_number = len(zin.infolist())
    for index, item in enumerate(zin.infolist()):
        try:
            progress_dialog(index, 1, files_number)
        except Canceled:
            return False
        else:
            zin.extract(item, output_directory)
    return True


def get_packages():
    addon_name = ADDON.getAddonInfo('name')
    kversion = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
    url = False
    if int(kversion) == 21:
        kname = '(v21 Omega)'
        url = 'https://github.com/Mastaaa1987/Mastaaa1987.github.io/releases/download/Test/kodi-omega.zip'
    elif int(kversion) == 20:
        kname = '(v20 Nexus)'
        url = 'https://github.com/Mastaaa1987/Mastaaa1987.github.io/releases/download/Test/kodi-nexus.zip'
    elif int(kversion) == 19:
        kname = '(v19 Matrix)'
        url = 'https://github.com/Mastaaa1987/Mastaaa1987.github.io/releases/download/Test/kodi-matrix.zip'
    if not url:
        dialog = xbmcgui.Dialog()
        message = 'Ungültige Kodi Version'
        dialog.ok(addon_name, "%s. MastaaaTV Installer wird nun geschlossen. " % message)
    else:
        response = urllib.request.urlopen(url)
        try:
            data = read(response, MyProgressDialog("MastaaaTV %s wird heruntergeladen..." % kname))
        except Canceled:
            message = "Download abgebrochen"
        else:
            addon_folder = xbmcvfs.translatePath(os.path.join('special://', 'home'))
            if extract(io.BytesIO(data), addon_folder, MyProgressDialog("MastaaaTV wird installiert...")):
                message = "MastaaaTV wurde erfolgreich installiert"
            else:
                message = "Die Installation wurde abgebrochen"
        dialog = xbmcgui.Dialog()
        dialog.ok(addon_name, "%s. MastaaaTV wird nun geschlossen. " % message)
        os._exit(0)
