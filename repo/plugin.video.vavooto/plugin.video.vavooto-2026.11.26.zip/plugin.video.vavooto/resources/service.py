# -*- coding: utf-8 -*-

import os, xbmc, time, xbmcvfs, xbmcaddon, shutil, xbmcgui
from datetime import datetime, timedelta

#addonInfo =
datapath = xbmcvfs.translatePath(xbmcaddon.Addon("plugin.video.vavooto").getAddonInfo('profile'))
cachepath = os.path.join(datapath, "cache")
temppath = cachepath
tdb = os.path.join(cachepath, 'tmp.db')
db = os.path.join(datapath, 'epg.db')
if os.path.exists(db):
    os.remove(db)
if os.path.exists(tdb):
    shutil.copyfile(tdb, db)

from vavoo.epg import service as epg
from vavoo import sql
from vavoo.utils import *

# con = utils.con

def add_tables():
    cur = con.cursor()
    cur.execute('CREATE TABLE IF NOT EXISTS epg ( "id" INTEGER PRIMARY KEY AUTOINCREMENT, "cid" TEXT, "start" INTEGER, "end" INTEGER, "title" TEXT, "desc" TEXT, "lang" TEXT)')
    cur.execute('CREATE TABLE IF NOT EXISTS epgs ( "id" INTEGER PRIMARY KEY AUTOINCREMENT, "rid" TEXT, "mid" TEXT, "mn" TEXT, "tid" TEXT, "tn" TEXT, "display" TEXT, "ol" TEXT, "ml" TEXT, "tl" TEXT)')
    cur.execute('CREATE TABLE IF NOT EXISTS settings ( "name" TEXT, "value" TEXT)')
    con.commit()
    return True

def check_epg_tables():
    sqldata = sql.epg
    cur = con.cursor()
    for row in sqldata:
        cur.execute('SELECT * FROM epgs WHERE rid="' + row[1] + '"')
        data = cur.fetchone()
        if not data:
            cur.execute('INSERT INTO epgs VALUES (?,?,?,?,?,?,?,?,?,?)', row)
    con.commit()
    return True

def check():
    if add_tables():
        if check_epg_tables():
            cur = con.cursor()
            cur.execute('SELECT * FROM settings WHERE name="timestamp"')
            data = cur.fetchone()
            if data:
                timestamp = int(time.time())
                if not timestamp > int(data['value']):
                    #xbmc.log('RETURN', xbmc.LOGINFO)
                    return
            #xbmc.log('SERVICE', xbmc.LOGINFO)
            if getSetting("epg") == "true":
                epg.run_grabber()

def stalker_check():
    ok, c = sel_cache(0, 'portale')
    if not ok:
        from vavoo.stalker import choose_portale
        choose_portale()
    ok, portale = sel_cache(0, 'portale')
    if ok:
        from threading import Thread
        from vavoo.stalker import new_mac
        from vavoo.vjlive import get_stalker_channels
        jobs = []
        for url in portale:
            ok, mac = sel_cache(0, 'mac', url)
            if not ok:
                ok, status = sel_cache(0, 'portal_ok', url)
                if (not ok) or (ok and status != "BLOCKED"):
                    p = Thread(target=new_mac, args=(True, True, url, ))
                    jobs.append(p)
                    p.start()
        if len(jobs) > 0:
            if len(global_vars) == 0: global_vars.append(len(jobs)); global_vars.append(len(jobs)); global_vars.append(len(portale))
            elif len(global_vars) == 1: global_vars[0] = len(jobs); global_vars.append(len(jobs)); global_vars.append(len(portale))
            else: global_vars[0] = len(jobs); global_vars[1] = len(jobs); global_vars[2] = len(portale)

            bg.create('Stalker Portale', 'Teste MAC Adressen: %s Jobs ausstehend' % str(len(jobs)))
            for j in jobs:
                j.join()
            bg.close()
        ls, lo, lb, lp = 0, 0, 0, len(portale)
        for url in portale:
            ok, mac = sel_cache(0, 'mac', url)
            if ok:
                ok, status = sel_cache(0, 'portal_ok', url)
                if ok and status == "OK": lo += 1
            else:
                ok, status = sel_cache(0, 'portal_ok', url)
                if ok and status == "BLOCKED": lb += 1
                elif ok and status == "NETWORK": ls += 1
                else: ls += 1
        dialog.notification("Stalker Portale %s" % str(lp), 'Ok: %s, Blocked: %s, Network: %s' % (str(lo), str(lb), str(ls)), xbmcgui.NOTIFICATION_INFO, 4000)
        logg('Portale: %s - Ok: %s, Blocked: %s, Failed Network: %s' % (str(lp), str(lo), str(lb), str(ls)))
    logg('stalker_check')

if getSetting("multi_stalker") == "true":
    stalker_check()

check()

