# -*- coding: utf-8 -*-
import sys, re, requests, time, xbmcgui, xbmc, json, vavoosigner, base64, sqlite3, os
from datetime import datetime
from resources.lib import utils
try:
    from infotagger.listitem import ListItemInfoTag
    tagger = True
except: tagger = False

vavoourl="https://www2.vavoo.to/live2/index"
unicode = str
db = os.path.join(utils.datapath, 'epg.db')
con = False
if os.path.exists(db):
    con = sqlite3.connect(db)
    con.row_factory = lambda c, r: dict([(col[0], r[idx]) for idx, col in enumerate(c.description)])
    con.text_factory = lambda x: unicode(x, errors='ignore')

def resolve_link(link):
    _data='{"token":"26fY7-FIvyz_UA5t9T_ndXB02KgaCT-jDx0uA9CE7iRAO_V2lCSGkAzzTXOpjHZHBvOoKcuq1OVCnbYX035d8698U0OYDaLo-7p8BJJIJNj7d1z-7byaQDuDFdEHPbnZAKAxG_fskVIrE0XkBV7_HbBnlIBDQ_EgxA","reason":"app-focus","locale":"de","theme":"light","metadata":{"device":{"type":"Handset","brand":"Xiaomi","model":"21081111RG","name":"21081111RG","uniqueId":"33267ca74bec24c7"},"os":{"name":"android","version":"7.1.2","abis":["arm64-v8a","armeabi-v7a","armeabi"],"host":"non-pangu-pod-sbcp6"},"app":{"platform":"android","version":"1.1.2","buildId":"97245000","engine":"jsc","signatures":["7c8c6b5030a8fa447078231e0f2c0d9ee4f24bb91f1bf9599790a1fafbeef7e0"],"installer":"com.android.secex"},"version":{"package":"net.dezor.browser","binary":"1.1.2","js":"1.2.9"}},"appFocusTime":1589,"playerActive":false,"playDuration":0,"devMode":false,"hasMhub":false,"castConnected":false,"package":"net.dezor.browser","version":"1.2.9","process":"app","firstAppStart":1681125328576,"lastAppStart":1681125328576,"ipLocation":null,"adblockEnabled":true,"proxy":{"supported":true,"enabled":true}}'
    signed = requests.post("https://www.dezor.net/api/app/ping", data=_data).json()["mhub"]
    _headers={"user-agent": "MediaHubMX/2", "accept": "application/json", "content-type": "application/json; charset=utf-8", "content-length": "158", "accept-encoding": "gzip", "Host": "www.kool.to", "mediahubmx-signature":signed}
    _data={"language":"de","region":"AT","url":link.replace("oha.to/oha-tv", "kool.to/kool-tv").replace("huhu.to/huhu-tv", "kool.to/kool-tv"),"clientVersion":"1.1.3"}
    url = "https://www.kool.to/kool-cluster/mediahubmx-resolve.json"
    return requests.post(url, data=json.dumps(_data), headers=_headers).json()[0]["url"]

def filterout(name):
    name = re.sub("( (SD|HD|FHD|UHD|H265))?( \\(BACKUP\\))? \\(\\d+\\)$", "", name)
    name = re.sub("(\(.*\)|DE : | \|\w| FHD| HD\+| HD| 1080| AUSTRIA| GERMANY| DEUTSCHLAND|HEVC|RAW| SD| YOU)", "", name).strip(".")
    name = name.replace("EINS", "1").replace("ZWEI", "2").replace("DREI", "3").replace("SIEBEN", "7").replace("  ", " ").replace("TNT", "WARNER").replace("III", "3").replace("II", "2").replace("BR TV", "BR").strip()
    if "ALLGAU" in name: name = "Allgau Tv"
    if all(ele in name for ele in ["1", "2", "3"]): name = "1-2-3.tv"
    if "HR" in name and "FERNSEHEN" in name: name = "hr-fernsehen"
    elif "DAS ERSTE" in name: name = "Das Erste"
    elif "EURONEWS" in name: name = "Euronews"
    elif "NICKEL" in name: name = "Nickelodeon"
    elif "ORF" in name:
        if "SPORT" in name: name = "ORF Sport"
        elif "3" in name: name = "ORF 3"
        elif "2" in name: name = "ORF 2"
        elif "1" in name: name = "ORF 1"
        elif "I" in name: name = "ORF 1"
    elif "SONY" in name: name = "AXN" if "AXN" in name else "Sony Channel"
    elif "ANIXE" in name: name = "Anixe Serie HD"
    elif "HEIMA" in name: name = "Heimatkanal"
    elif "SIXX" in name: name = "SIXX"
    elif "SWR" in name: name = "SWR Fernsehen RP"
    elif "CENTRAL" in name or "VIVA" in name: name = "Comedy Central"
    elif "BR" in name and "FERNSEHEN" in name: name = "BR"
    elif "DMAX" in name: name = "DMAX"
    elif "DISNEY" in name: name = "Disney Channel"
    elif "KINOWELT" in name: name = "Kinowelt"
    elif "MDR" in name: name = "MDR Sachsen"
    elif "RBB" in name: name = "rbb Berlin"
    elif "SERVUS" in name: name = "Servus TV HD"
    elif "RTL" in name:
        if "CRIME" in name: name = "RTL Crime"
        if "SUPER" in name: name = "Super RTL"
        elif "UP" in name: name = "RTLup"
        elif "PLUS" in name: name = "RTL Plus"
        elif "PASSION" in name: name = "RTL Passion"
        elif "LIVING" in name: name = "RTL Living"
        elif "SPORT" in name: name = "RTL+ Sport"
        elif "NITRO" in name: name = "RTL Nitro"
        elif "RTL 2" in name: name = "RTL II"
    elif "NITRO" in name: name = "RTL Nitro"
    elif "UNIVERSAL" in name: name = "Universal Channel"
    elif "WDR" in name: name = "WDR Köln"
    elif "PLANET" in name: name = "Animal Planet" if "ANIMAL" in name else "Planet"
    elif "SYFY" in name: name = "Syfy"
    elif "E!" in name: name = "E! Entertainment"
    elif "ENTERTAINMENT" in name: name = "E! Entertainment"
    elif "STREET" in name: name = "13th Street"
    elif "WUNDER" in name: name = "Welt der Wunder"
    elif "KAB" in name and "1" in name:
        if "CLA" in name: name = "kabel eins classics"
        elif "DOKU" in name: name = "Kabel Eins Doku"
        else: name = "Kabel 1"
    elif "PRO" in name:
        if "FUN" in name: name = "Pro7 Fun"
        elif "MAXX" in name: name = "ProSieben Maxx"
        else: name = "ProSieben"
    elif "SKY" in name:
        if not "PREMIEREN" in name and "PREMIERE" in name:
            name = name.replace("PREMIERE", "PREMIEREN")
        if "PREMIEREN" in name and not "CINEMA" in name: name = "Sky Cinema"
        if "24" in name: name = "Sky Cinema" if "PREMIERE" in name else "Sky Cinema"
        elif "SKY 1" in name: name = "SKY 1"
        elif "ATLANTIC" in name: name = "Sky Atlantic"
        elif "ACTION" in name: name = "Sky Action"
        elif "BEST" in name or "HITS" in name: name = "Sky Cinema"
        elif "CINEMA" in name and "COMEDY" in name: name = "Sky Cinema"
        elif "COMEDY" in name: name = "Sky Comedy"
        elif "FAMI" in name: name = "Sky Cinema Family"
        elif "SHOW" in name: name = "Sky Serien & Shows"
        elif "SPECI" in name: name = "Sky Cinema"
        elif "THRILLER" in name: name = "Sky Cinema Thriller"
        elif "FUN" in name: name = "Sky Cinema Fun"
        elif "CLASSIC" in name: name = "Sky Cinema Classics"
        elif "NOSTALGIE" in name: name = "Sky Cinema"
        elif "KRIM" in name: name = "Sky Krimi"
        elif "SKY 24" in name: name = "Sky Cinema+24"
        elif "CRIME" in name: name = "Sky Crime"
        elif "SPORT" in name: name = "Sky Sport"
        elif "SELECT" in name: name = "Sky Select"
        elif "REPLAY" in name: name = "Sky Replay"
        elif "POPCORN" in name: name = "Sky Popcorn"
        elif "CINEMA" in name: name = "Sky Cinema"
        elif "BUNDESLIGA" in name: name = "Sky Bundesliga"
        elif "BOX" in name: name = "Sky Box"
        elif "NATURE" in name: name = "Sky Nature"
        elif "SKY 1" in name: name = "Sky 1"
    elif "ZEE" in name: name = "Zee One"
    elif "DELUX" in name: name = "Deluxe Music"
    elif "DISCO" in name: name = "Discovery Channel"
    elif "TLC" in name: name = "TLC"
    elif "HISTORY" in name: name = "History Channel"
    elif "VISION" in name: name = "MotorVision"
    elif "INVESTIGATION" in name or "A&E" in name: name = "Crime + Investigation"
    elif "AUTO" in name: name = "Auto Motor und Sport"
    elif "WELT" in name: name = "Welt der Wunder" if "WUNDER" in name else "Welt"
    elif "NAT" in name and "GEO" in name: name = "Nat Geo Wild" if "WILD" in name else "National Geographic"
    elif "3" in name and "SAT" in name: name = "3sat"
    elif "WARNER" in name:
        if "SERIE" in name: name = "Warner Serie"
        elif "FILM" in name: name = "Warner Film"
        elif "COMEDY" in name: name = "Warner Comedy"
    elif "VOX" in name:
        if "+" in name: name = "VOXup"
        elif "UP" in name: name = "VOXup"
        else: name = "VOX"
    elif "SAT" in name and "1" in name:
        if "GOLD" in name: name = "Sat1 Gold HD"
        elif "EMOT" in name: name = "Sat.1 emotions"
        else: name = "Sat 1"
    elif "REPLAY" in name: name = "Fix & Foxi" if "FIX" in name else "Sky Replay"
    elif "FOX" in name: name = "FOX"
    elif "TELEKOM BUNDESLIGA" in name: name = "TELEKOM BUNDESLIGA"
    elif "ZDF INFO" in name: name = "ZDFinfokanal"
    elif "ZDF NEO" in name: name = "ZDF neo"
    elif "ZDF" in name: name = "ZDF"
    elif "WAIDWERK" in name: name = "Waidwerk TV"
    elif "V SPORT" in name or "V SERIES" in name or "V FILM" in name: name = "V Film"
    elif "TV3" in name: name = "TV3"
    elif "TV INGOLSTADT" in name or "TV MAINFRANKEN" in name or "TV OBERFRANKEN" in name: name = "TV"
    elif "TV 2" in name: name = "TV2"
    elif "TOGGO PLUS" in name: name = "TOGGOplus"
    elif "TELEKOM BUNDESLIGA" in name: name = "Telekom Bundesliga"
    elif "TELE 5" in name: name = "Tele 5"
    elif "TAGESSCHAU" in name: name = "tagesschau24"
    elif "STERN FILME" in name: name = "Stern Filme"
    elif "SR" in name: name = "SR Fernsehen"
    elif "SPORTDIGITAL" in name or "SPORTDIGITALL" in name or "SPORT DIGITAL" in name: name = "Sportdigital"
    elif "SPORT 1" in name or "SPORT1" in name: name = "Sport1+"
    elif "SPIEGEL" in name: name = "Spiegel TV Wissen" if "WISSEN" in name else "Spiegel Geschichte HD"
    elif "Sky Cinema BOX" in name: name = "Sky Cinema Box"
    elif "SILVERLINE" in name: name = "Silverline"
    elif "S. SPORT" in name: name = "S. Sport"
    elif "SACHSEN" in name: name = "Sachsen Fernsehen"
    elif "SAARLAND" in name: name = "Saarland Fernsehen"
    elif "REGIO TV" in name: name = "Regio TV"
    elif "RAKUTEN" in name: name = "Rakuten TV"
    elif "QVC" in name: name = "QVC"
    elif "PLUTO TV" in name: name = "Pluto TV"
    elif "OK" in name: name = "OK TV"
    elif "NICK JR" in name or "NICK JUNIOR" in name or "NICKJR" in name: name = "Nick Junior"
    elif "N24 DOCU" in name or "N24 DOKU" in name: name = "N24 Doku"
    elif "MAX KINO" in name: name = "Max Kino"
    elif "MAGENTA SPORT" in name: name = "Magenta Sport"
    elif "MAGENTA FUSSBALL" in name: name = "Magenta Fussball"
    elif "EUROSPORT 2" in name: name = "Eurosport 2"
    elif "EUROSPORT 1" in name: name = "Eurosport 1"
    elif "EAGLE" in name: name = "EAGLE"
    elif "DB LIGA" in name: name = "DB Liga"
    elif "DAZN" in name: name = "DAZN 1"
    elif "BLUETV" in name: name = "BlueTV"
    elif "AMAZON PRIME" in name: name = "Amazon Prime"
    elif "SPORT KLUB" in name: name = "Sport Klub"
    elif "PINK" in name: name = "PINK"
    elif "CINESTAR" in name: name = "CINESTAR"
    elif "CINEMAX" in name: name = "CINEMAX"
    elif "ARENA SPORT" in name: name = "Arena Sport"
    elif "ARTE" in name: name = "arte"
    elif "AXN" in name: name = "Sony Channel" if "WHITE" in name else "AXN"
    elif "KIKA" in name: name = "Kika"
    elif "MTV" in name: name = "MTV Germany"
    elif "N-TV" in name: name = "n-tv"
    elif "ONE" in name: name = "One"
    elif "ACHT" in name or "Allgau Tv" in name or "ARD ALPHA" in name or "AUGSBURG" in name or "BADEN TV" in name or "BIBEL TV" in name or "BILD TV" in name: name = '00 Der Rest'
    elif "BOLLYWOOD" in name or "BON GUSTO" in name or "BOOMERANG" in name or "CAMPUS TV" in name or "DW TV" in name or "ESPORTS 1" in name or "GAME OF THRONES CHANNEL" in name: name = '00 Der Rest'
    elif "GOLDSTAR" in name or "HGTV" in name or "HSE" in name or "INDIANA JONES CHANNEL" in name or "JUKEBOX" in name or "JUWELO TV" in name or "KRONE HIT TV" in name: name = '00 Der Rest'
    elif "LIGHT CHANNEL" in name or "MDF 1" in name or "NIEDERBAYERN" in name or "NOA 4" in name or "NRWISION" in name or "OBERLAUSITZ" in name or "OBERPFALZ" in name: name = '00 Der Rest'
    elif "OE24.TV" in name or "ORF" in name or "PIRATES OF THE CARIBBEAN" in name or "PULS 4" in name or "PUNKTUM" in name or "RBB" in name or "RBW" in name: name = '00 Der Rest'
    elif "Regio TV" in name or "RENNSTEIG TV" in name or "RFH TV" in name or "RFO" in name or "RNF" in name or "ROMANCE TV" in name or "SALVE TV" in name: name = '00 Der Rest'
    elif "SEENLUFT 24" in name or "SONNENKLAR TV" in name or "STINGRAY CLASSICA" in name or "TASTEMADE" in name or "TOM AND JERRY" in name or "Waidwerk TV" in name: name = '00 Der Rest'
    elif "XITE" in name or "ARISTO TV" in name or "AUGSBURG TV" in name or "BABY TV" in name or "BALLERMANN TV" in name or "BERGBLICK" in name or "BLK REGIONAL TV" in name: name = '00 Der Rest'
    elif "CARTOONITO" in name or "CHANNEL 21" in name or "CHEMNITZ FERNSEHEN" in name or "CINE MAX JURASSIC PARK" in name or "CRACTION" in name or "CROTV" in name or "DABEITV" in name or "DIE NEUE ZEIT TV" in name: name = '00 Der Rest'
    elif "DRESDEN" in name or "DW" in name or "ECHT JETZT" in name or "EDGE SPORT" in name or "ERZ TV STOLLBERG" in name or "FRANKEN" in name or "FS1" in name or "GENIUS PLUS TV" in name or "GO2 TRAVEL" in name: name = '00 Der Rest'
    elif "HAMBURG 1" in name or "HEALTH TV" in name or "HSE" in name or "JUWELO" in name or "K-TV" in name or "KIEL TV" in name or "KULTUR MD" in name or "LUXE TV" in name or "MORE THAN SPORTS TV" in name: name = '00 Der Rest'
    elif "MOVIES CH" in name or "MYTVPLUS" in name or "M\u00dcNCHEN TV" in name or "NAHE TV" in name or "NATURKANAL1" in name or "NICK EMMA EINFACH MAGISCH" in name or "NIEDERBAYERN TV SATELLIT" in name: name = '00 Der Rest'
    elif "NOA 4" in name or "OF TV OFFENBACH" in name or "OFFENER KANAL MAGDEBURG" in name or "OLDENBURG 1" in name or "OTVA" in name or "PARANORMAL" in name or "PARLAMENTS FERNSEHEN 2" in name: name = '00 Der Rest'
    elif "PARLAMENTSFERNSEHEN 1" in name or "PEARL TV" in name or "RAN 1" in name or "RED BULL TV" in name or "REGIONALFERNSEHEN HARZ" in name or "RFO ROSENHEIM" in name or "RHEIN NECKAR FERNSEHEN" in name: name = '00 Der Rest'
    elif "RHEINISCHE FACHHOCHSCHULE K\u00d6LN" in name or "RTV" in name or "Saarland Fernsehen" in name or "Silverline" in name or "SONUS FM ALEMANIA" in name or "Stern Filme" in name or "TEEN" in name: name = '00 Der Rest'
    elif "TOTALLY TURTLES" in name or "TV BAYERN" in name or "TV RUS +" in name or "TVA OSTBAYERN" in name or "VICTORIOUS" in name or "WESTERWALD-WIED TV" in name or "WETTIN TV" in name or "6EREN" in name: name = '00 Der Rest'
    elif "BIBELTV" in name or "CANAL 9" in name or "DER AKTION R TV" in name or "DEUTSCHE SINEMA" in name or "DEUTSCHE SPORT" in name or "DK4" in name or "DR RAMASJANG" in name or "DR1" in name or "DR2" in name or "DW" in name: name = '00 Der Rest'
    elif "FC BAYERN" in name or "FEUERWEHRMANN SAM TV" in name or "KINDER SENDER" in name or "KINDERM RCHEN" in name or "MASHA UND DER B R" in name or "MR. BEAN" in name or "MUENCHEN" in name or "NBA TV" in name or "ONEBY" in name: name = '00 Der Rest'
    elif "PARAMOUNT NETWORK" in name or "PJ MASKS" in name or "TV3" in name or "VH1 CLASSIC" in name or "VIASAT EXPLORE" in name or "VIASAT NATURE" in name or "YAKARI TV" in name: name = '00 Der Rest'
    elif "TOTALLY TURTLES" in name or "SPONGEBOB" in name or "Regio TV" in name or "ORF" in name or "MUXX TV" in name or "MR BEAN" in name or "DER AKTION" in name or "CITY TV" in name or "BAYERISCHES" in name or "Waidwerk TV" in name: name = '00 Der Rest'
    return name

def get_epg_data():
    if int(utils.addon.getSetting("epg_provider")) == 0:
        epg_data = {'1-2-3.tv': ['4724', 'http://ngiss.t-online.de/cm1s/media/ca0c611992e1d587d76fab310e74ca4e32ff69ab.png'], '13th Street': ['471', 'http://ngiss.t-online.de/cm1s/media/668cd4d06f6981b82841f40fad42bc350babb056.png'], '3sat': ['392', 'http://ngiss.t-online.de/cm1s/media/f0fc63107fddc5c72d70a64f90f9672710e3a3d9.png'], 'Allgäu TV': ['448', 'http://ngiss.t-online.de/cm1s/media/d37488ac6d2572b3cda8b5abc35f2ef632f46d8d.png'], 'Animal Planet': ['105', 'http://ngiss.t-online.de/cm1s/media/cd0ca6f68c634ba2fd4ce665043f3cefdd1c1c9d.png'], 'Anixe HD': ['452', 'http://ngiss.t-online.de/cm1s/media/7d936048c94ca83281a61951170b5ad0da756584.png'], 'Anixe Serie HD': ['4777', 'http://ngiss.t-online.de/cm1s/media/f105ac8c8e8dbede59277c3b2019c65ea1ecfc95.png'], 'ARD-alpha': ['479', 'http://ngiss.t-online.de/cm1s/media/4f1286373cd3362649d2e4ae1692ab8a360bf773.png'], 'arte': ['394', 'http://ngiss.t-online.de/cm1s/media/a94bb4917f279b02cb739e788c18f38a009f95a0.png'], 'ATV': ['161', 'http://ngiss.t-online.de/cm1s/media/ecd02c711e2a96d79702ef779035c9b03ecb5811.png'], 'Auto Motor und Sport': ['108', 'http://ngiss.t-online.de/cm1s/media/8ffbb0a95849b6c7af04aeaea5c2e1680c6cb0ad.png'], 'AXN': ['110', 'http://ngiss.t-online.de/cm1s/media/df6a8f84c2ecbe26b090e37b782db46b9d98b1bb.png'], 'Baby TV': ['109', 'http://ngiss.t-online.de/cm1s/media/5ba6b3a95fbbbce05e3b62e45196771dbf2fe33e.png'], 'BBC entertainment': ['454', 'http://ngiss.t-online.de/cm1s/media/f41b3e216d38d542dd49f4e3d0f1d21d87dd43cb.png'], 'Beate-Uhse.TV': ['107', 'http://ngiss.t-online.de/cm1s/media/40e5d10666540db54a54bb2092a47faa39a52ec8.png'], 'Bergblick': ['45', 'http://ngiss.t-online.de/cm1s/media/2f68a8b738d31415c99da911bea93a97020ee1f3.png'], 'Bibel TV': ['485', 'http://ngiss.t-online.de/cm1s/media/4754ecc68c5e078e80ac2d5435726b2a9b016b90.png'], 'Bon Gusto': ['117', 'http://ngiss.t-online.de/cm1s/media/65ebe25329d441714dc70fa737e90c68c2a6e129.png'], 'BR': ['407', 'http://ngiss.t-online.de/cm1s/media/40d2ab4ade690ec7e4d965e586a62ca937ee091c.png'], 'Cartoon Network': ['4512', 'http://ngiss.t-online.de/cm1s/media/f73ed871486bd026ffc3ff4cf5e5ac2eeaf6f746.png'], 'Channel21': ['5176', 'http://ngiss.t-online.de/cm1s/media/eb86d7033816033536232cfa5a1c03c396b64d28.png'], 'Comedy Central': ['50', 'http://ngiss.t-online.de/cm1s/media/766e5d3738b790d93690b9a6a40e65b99cb73d6b.png'], 'Crime + Investigation': ['106', 'http://ngiss.t-online.de/cm1s/media/98c3430141aaf756c564aedafebb36d0258f34c1.png'], 'Spiegel TV Wissen': ['186', 'http://ngiss.t-online.de/cm1s/media/7502f4f2236a2916323f079e168237ffd7150a25.png'], 'Das Erste': ['373', 'http://ngiss.t-online.de/cm1s/media/3711d16d0e3570276ebba175620385b5f4ff18f4.png'], 'DAZN 1': ['5507', 'http://ngiss.t-online.de/cm1s/media/7c93cbccfa99c23171441af6ba8f35cd22d9cf28.png'], 'DAZN 2': ['5508', 'http://ngiss.t-online.de/cm1s/media/141a3d65b2f92f7e2a52c93d30a0a29f2184466d.png'], 'Deluxe Music': ['25', 'http://ngiss.t-online.de/cm1s/media/d31840e010d6da58d1aeb2009b04f5a9924481c1.png'], 'Deutsches Musik Fernsehen': ['5312', 'http://ngiss.t-online.de/cm1s/media/febc89b3d6ee8a59fce7915cc9ccc7b4448cfd3e.png'], 'Discovery Channel': ['468', 'http://ngiss.t-online.de/cm1s/media/6e522d9ae4b2a9a8f686281f7d3adff2d8862ee3.png'], 'Disney Channel': ['27', 'http://ngiss.t-online.de/cm1s/media/8ddb880c89e880c0a150c17e355138b0341ed6ee.png'], 'DMAX': ['429', 'http://ngiss.t-online.de/cm1s/media/f47210c8539cdcb85e4c468f83a281f6daa66b58.png'], 'eSPORTS1': ['191', 'http://ngiss.t-online.de/cm1s/media/6e4cee1ab1da1d86af73c1bfb533f11fe7711c5b.png'], 'Eurosport 1': ['389', 'http://ngiss.t-online.de/cm1s/media/18f200745e93b6c9848237acaaa008ea9f520f94.png'], 'Eurosport 2': ['18', 'http://ngiss.t-online.de/cm1s/media/fbc41d77249de69bb35febcff1bb74dd87a3b031.png'], 'GEO Television': ['153', 'http://ngiss.t-online.de/cm1s/media/267643eb7bc861bb7e308a303f66e5301e848db7.png'], 'HH1': ['244', 'http://ngiss.t-online.de/cm1s/media/254cb8179b6bf0b87bf6e8907d184203dbca13b3.png'], 'Heimatkanal': ['661', 'http://ngiss.t-online.de/cm1s/media/daabe8d88933d58ca50ef01e692058fe39759627.png'], 'HGTV': ['3583', 'http://ngiss.t-online.de/cm1s/media/f1d655994f8af8a636f983c9d3fe1a862501766d.png'], 'History Channel': ['162', 'http://ngiss.t-online.de/cm1s/media/c991f75a9b93fb49233fe78cbcc37007d99e01ad.png'], 'hr-fernsehen': ['386', 'http://ngiss.t-online.de/cm1s/media/b11ecb6905afbf9f82d9cd8624c242013a78824e.png'], 'HSE24': ['451', 'http://ngiss.t-online.de/cm1s/media/af654601ccb9e529f85c736e2c66e9fb96d62acc.png'], 'Jukebox': ['132', 'http://ngiss.t-online.de/cm1s/media/9735a7ac5cfcf3c56acd644069751c8c5b72bbe8.png'], 'Kabel 1': ['405', 'http://ngiss.t-online.de/cm1s/media/e92cc62717350cd0378f1191c21a3512362c65a1.png'], 'kabel eins classics': ['157', 'http://ngiss.t-online.de/cm1s/media/3d6c4e11c8058b35f0726c1e25ab1b391a2ada75.png'], 'Kabel Eins Doku': ['573', 'http://ngiss.t-online.de/cm1s/media/ca3279d86270655d49eb50a361e1dcb4564bf39e.png'], 'Kika': ['387', 'http://ngiss.t-online.de/cm1s/media/7d9a501ddc07382fcfdbb0c0797916ba4e78cacd.png'], 'Kinowelt': ['137', 'http://ngiss.t-online.de/cm1s/media/8f80fdd4f8fe6853800aeec106062fc2ee1d5ab4.png'], 'K-TV': ['487', 'http://ngiss.t-online.de/cm1s/media/e942c7a5d723ecea30ee55121067d86cf541f262.png'], 'Lust Pur': ['32', 'http://ngiss.t-online.de/cm1s/media/35264aa89ecba0a3ceb4b0f6f4e0eae0eefb9fcf.png'], 'Marco Polo TV': ['5295', 'http://ngiss.t-online.de/cm1s/media/f8877cba3e440dc9d7d62e1bd51250b06fe2b03a.png'], 'MDR Sachsen': ['370', 'http://ngiss.t-online.de/cm1s/media/8e11c0abde6c90a68507070c73b443401a24fcff.png'], 'MotorVision': ['604', 'http://ngiss.t-online.de/cm1s/media/744220404bda665ff97622e9adc9969540e05895.png'], 'MTV Germany': ['28', 'http://ngiss.t-online.de/cm1s/media/95d8d4289c6a6056f67cac44eded24ad7b8cce8a.png'], 'München TV': ['241', 'http://ngiss.t-online.de/cm1s/media/0c7f41025f6eb921088338aaca24116787652f0c.png'], 'N24 Doku': ['553', 'http://ngiss.t-online.de/cm1s/media/bf4ce870d460dcdb3b1e573d58a14137a7d002ea.png'], 'National Geographic': ['35', 'http://ngiss.t-online.de/cm1s/media/c9d4a2fb172069fc67d4170738cdbbc225f079f6.png'], 'Nat Geo Wild': ['569', 'http://ngiss.t-online.de/cm1s/media/deec95134d0baec0f4030cb9c96a1f7348419c30.png'], 'NDR': ['377', 'http://ngiss.t-online.de/cm1s/media/d72e120a384a97f269eb891ad135fb4d115decbb.png'], 'Nick Junior': ['221', 'http://ngiss.t-online.de/cm1s/media/cfa3bf59d761bb21a108955f7dd919d04ef20734.png'], 'NickToons': ['4405', 'http://ngiss.t-online.de/cm1s/media/9361033a288cb7f1f525416eef433f1d47c38abf.png'], 'n-tv': ['376', 'http://ngiss.t-online.de/cm1s/media/1c3073dd69376d57149afdb1791c2576724000f2.png'], 'One': ['402', 'http://ngiss.t-online.de/cm1s/media/70b3ed315768d8799f8577aad1003e4b2758b197.png'], 'PHOENIX': ['371', 'http://ngiss.t-online.de/cm1s/media/0630170ba6401342025bf2ca1b1ed337e653bed5.png'], 'ProSieben': ['374', 'http://ngiss.t-online.de/cm1s/media/a7f56de9d6b8af8708bda4a48349ab6a3f713ecd.png'], 'Pro7 Fun': ['259', 'http://ngiss.t-online.de/cm1s/media/1f0e9026087e023f7464640bcbe4eaed6cce4055.png'], 'ProSieben Maxx': ['396', 'http://ngiss.t-online.de/cm1s/media/8bbd8b6505244eadf79acc39552459c44c052ffa.png'], 'QVC': ['446', 'http://ngiss.t-online.de/cm1s/media/d985b7be308774435b4e824e87857be6d01626a0.png'], 'Radio Bremen TV': ['368', 'http://ngiss.t-online.de/cm1s/media/cd648267d785ddb46756676b9d0b5ee806a60a7d.png'], 'rbb Berlin': ['384', 'http://ngiss.t-online.de/cm1s/media/3c5a2a45fa454d43b49eb1a696cafd0a4eeb1c86.png'], 'RNF': ['246', 'http://ngiss.t-online.de/cm1s/media/c1dd9de99f0eabc4c3f8efa1a6a7c15631783360.png'], 'RiC': ['5329', 'http://ngiss.t-online.de/cm1s/media/d3793d2e6881bb5ba207356a5ac262a4c96264eb.png'], 'Romance TV': ['658', 'http://ngiss.t-online.de/cm1s/media/26147f4735983c4f20ad71c01ba95f25b1a7ccc7.png'], 'RTL': ['404', 'http://ngiss.t-online.de/cm1s/media/3f21af88cf184a45ff4c54be37053ddd678e2456.png'], 'RTL II': ['382', 'http://ngiss.t-online.de/cm1s/media/c2f437c77a06daffbcaa14f5caed1b301abda6b7.png'], 'RTL Crime': ['216', 'http://ngiss.t-online.de/cm1s/media/fda6a6827c4ba695a264061adc0a8813eb83afa7.png'], 'RTL Living': ['227', 'http://ngiss.t-online.de/cm1s/media/df96334494725e0766bf3a22ac6ae3ea88611adf.png'], 'RTL Nitro': ['395', 'http://ngiss.t-online.de/cm1s/media/3e55a412683a498ae7e19077ea81b564bb1b271b.png'], 'RTL Passion': ['209', 'http://ngiss.t-online.de/cm1s/media/f723199cfa53cb06b833be3a91bc36f301fbafc8.png'], 'RTLup': ['542', 'http://ngiss.t-online.de/cm1s/media/f0eab07df247d9f64761c2d9f6e12d244d5ed0b5.png'], 'Sat 1': ['381', 'http://ngiss.t-online.de/cm1s/media/efd5a2c8992cd87d3fcc83b5b2399d12971bf89f.png'], 'Sat.1 emotions': ['224', 'http://ngiss.t-online.de/cm1s/media/fb8cf407e719419c47b394d4307cb3e7aa16c4ae.png'], 'Sat1 Gold HD': ['338', 'http://ngiss.t-online.de/cm1s/media/c4df738dfcdc4307911328c1368b717428f234d8.png'], 'Syfy': ['465', 'http://ngiss.t-online.de/cm1s/media/ea9846917902c635cd3c5b239bd2f0c5d23c0c98.png'], 'Servus TV HD': ['39', 'http://ngiss.t-online.de/cm1s/media/7705473aad92b6a66fbd0d0f845ba5a884d69989.png'], 'SIXX': ['380', 'http://ngiss.t-online.de/cm1s/media/2dc9daa2cdf850169e75d472bd42362f60a0cd7f.png'], 'Sky 1': ['576', 'http://ngiss.t-online.de/cm1s/media/1a2ed987272b88d35770eae839376b8807836a84.png'], 'Sky Action': ['40', 'http://ngiss.t-online.de/cm1s/media/62de0add95c271dede017fb50d22f6de51ffa34d.png'], 'Sky Atlantic': ['264', 'http://ngiss.t-online.de/cm1s/media/e9fd1abc76e3b402cf5ae4f65bf6798741cd214e.png'], 'Sky Sport Bundesliga 1': ['206', 'http://ngiss.t-online.de/cm1s/media/4200a7071dfb0095510d7ed65682da53ba833eec.png'], 'Sky Sport Bundesliga 10': ['5557', 'http://ngiss.t-online.de/cm1s/media/083d140c6df8ca522b605c2c9ca9fb24a92455f3.png'], 'Sky Sport Bundesliga 2': ['211', 'http://ngiss.t-online.de/cm1s/media/157acf7ce820d15b32b3b032403a32fb65958ac2.png'], 'Sky Sport Bundesliga 3': ['199', 'http://ngiss.t-online.de/cm1s/media/059d08de74e6183963d844496ffa1d96b7e264ef.png'], 'Sky Sport Bundesliga 4': ['232', 'http://ngiss.t-online.de/cm1s/media/1896c9e512a830512a50aead481612e623c7fc40.png'], 'Sky Sport Bundesliga 5': ['234', 'http://ngiss.t-online.de/cm1s/media/e1b0693d92286bae1481f232ff087a4f0cd3b7e1.png'], 'Sky Sport Bundesliga 6': ['231', 'http://ngiss.t-online.de/cm1s/media/18b38a657b0333c91513befb793a06e06d5e6f58.png'], 'Sky Sport Bundesliga 7': ['258', 'http://ngiss.t-online.de/cm1s/media/25af99e420b22dc62986815785d2eac63c9d132b.png'], 'Sky Sport Bundesliga 8': ['219', 'http://ngiss.t-online.de/cm1s/media/b23310b91343dae0296d313b692b52dbbdec8d69.png'], 'Sky Sport Bundesliga 9': ['237', 'http://ngiss.t-online.de/cm1s/media/282435adc67782bce8ea32e0b92173f6d76baf4f.png'], 'Sky Cinema Classics': ['200', 'http://ngiss.t-online.de/cm1s/media/14c205585d3d1c5728d0575c661dc0d12c340ef1.png'], 'Sky Cinema Family': ['572', 'http://ngiss.t-online.de/cm1s/media/4af8c51b0aae80d28cb887cd75fe15508aea515f.png'], 'Sky Cinema Fun': ['235', 'http://ngiss.t-online.de/cm1s/media/b49bd59ff13cb015a5ab9243bf102d6b3d1cc4be.png'], 'Sky Cinema +1': ['195', 'http://ngiss.t-online.de/cm1s/media/0b253961f1ed86531231b7ebef4856fe2393998c.png'], 'Sky Cinema+24': ['202', 'http://ngiss.t-online.de/cm1s/media/5371a1404566488319991aef236525c5cdd96fd0.png'], 'Sky Cinema Best Of 2019 HD': ['3844', 'http://ngiss.t-online.de/cm1s/media/2c4c6b314f2e5280c36b01434468d73c7d8c6ab7.png'], 'Sky Cinema Thriller': ['4356', 'http://ngiss.t-online.de/cm1s/media/e72acc4e943682e5c0fc1bc320a6fbe2b9675fd0.png'], 'Sky Crime': ['4924', 'http://ngiss.t-online.de/cm1s/media/55f7af6e6da0e5fe88c98d17969ec3567cde00c6.png'], 'Sky Documentaries': ['5143', 'http://ngiss.t-online.de/cm1s/media/d678db56c8ea3648fe89d02a8b017a8b9a7d9f06.png'], 'Sky Krimi': ['201', 'http://ngiss.t-online.de/cm1s/media/2092514be53beb3a7d0b25a95db91ed27c707c8b.png'], 'Sky Nature': ['5142', 'http://ngiss.t-online.de/cm1s/media/6ed382f8ee9fb14dd678d78dbe4d4d8c2f9ff0c5.png'], 'Sky Replay': ['3756', 'http://ngiss.t-online.de/cm1s/media/5727b8cc057a36b525abafb23b46d02bb24fed70.png'], 'Sky Showcase': ['5577', 'http://ngiss.t-online.de/cm1s/media/09629b5939190f0df366f958f199d6d499b2c4bd.png'], 'Sky Sport 1': ['192', 'http://ngiss.t-online.de/cm1s/media/de52c5d48628b03453d6c09ff0d625ccd9123329.png'], 'Sky Sport 10': ['5554', 'http://ngiss.t-online.de/cm1s/media/402fc1d16a4b7072aa3ec0a6382178a6a874afd6.png'], 'Sky Sport 2': ['212', 'http://ngiss.t-online.de/cm1s/media/a81a83173f2b76a9167bb872d535645d12ff16c5.png'], 'Sky Sport 3': ['189', 'http://ngiss.t-online.de/cm1s/media/1206e226d77c64a66c18676d2a4995ac0d4f528e.png'], 'Sky Sport 4': ['111', 'http://ngiss.t-online.de/cm1s/media/33e321e0ea47007d4fe5840b462f324425c04b77.png'], 'Sky Sport 5': ['114', 'http://ngiss.t-online.de/cm1s/media/174bc4e879e6dfe8da2da79a20d1cd12a2e64a11.png'], 'Sky Sport 6': ['113', 'http://ngiss.t-online.de/cm1s/media/dccedc966ee1e760137bbf38f34d86f0793ab7ed.png'], 'Sky Sport 7': ['127', 'http://ngiss.t-online.de/cm1s/media/2f260de91a03cc79f32ad816be1aae5e424fc523.png'], 'Sky Sport 8': ['261', 'http://ngiss.t-online.de/cm1s/media/b355966e88194e9b72e2879cece8735834a1b45a.png'], 'Sky Sport 9': ['187', 'http://ngiss.t-online.de/cm1s/media/68a5a9c16947d1423678be66c7223fc5f4e5d037.png'], 'Sky Sport Bundesliga': ['42', 'http://ngiss.t-online.de/cm1s/media/cf8a1da7411cef9e690ad178cedbd9dbe13ebdbd.png'], 'Sky Sport F1': ['4889', 'http://ngiss.t-online.de/cm1s/media/67d611a4e282db524f86d9424d2ce0921bdca5a3.png'], 'Sky Sport Golf': ['5558', 'http://ngiss.t-online.de/cm1s/media/20375ea6aa459f3e75ff52ef8dd025257f91c453.png'], 'Sky Sport Mix HD': ['5556', 'http://ngiss.t-online.de/cm1s/media/5494143bb12d192a5c0b69b5f93c2d3368e00fbd.png'], 'Sky Sport News': ['190', 'http://ngiss.t-online.de/cm1s/media/73b37ddf8cadce6a5c4a1ebdf70a526c2ae93719.png'], 'Sky Sport Premier League': ['5555', 'http://ngiss.t-online.de/cm1s/media/398c412f21c4d52385bffd49f852338d56b43808.png'], 'Sky Sport Tennis': ['198', 'http://ngiss.t-online.de/cm1s/media/e69c367167782ff684da93d889c980eec8ea0bfd.png'], 'Sky Sport Top Event': ['31', 'http://ngiss.t-online.de/cm1s/media/8693b13e8355d376c9b2c53e515e7f85abe659d9.png'], 'Sonnenklar': ['486', 'http://ngiss.t-online.de/cm1s/media/14573aebde590f886d975d5193a26dc6065c0683.png'], 'Spiegel Geschichte HD': ['4406', 'http://ngiss.t-online.de/cm1s/media/cb6141ae4226647544a9af4b6d69e41d557fe894.png'], 'Sport1+': ['44', 'http://ngiss.t-online.de/cm1s/media/074034f464715db15c5859b60b36558cac35a5e3.png'], 'Sportdigital': ['194', 'http://ngiss.t-online.de/cm1s/media/36207a17b0a5760b3977dcf130e53ce30f09c594.png'], 'SR Fernsehen': ['379', 'http://ngiss.t-online.de/cm1s/media/784cfb3e89c660ecf9f02bae301f40f875996af9.png'], 'Super RTL': ['403', 'http://ngiss.t-online.de/cm1s/media/d83d20be89d5f6899d8885b944b109928f7a3171.png'], 'SWR Fernsehen RP': ['393', 'http://ngiss.t-online.de/cm1s/media/033802069c0c3086585d215e0592501669f15f1c.png'], 'Südwest Fernsehen': ['398', 'http://ngiss.t-online.de/cm1s/media/033802069c0c3086585d215e0592501669f15f1c.png'], 'tagesschau24': ['400', 'http://ngiss.t-online.de/cm1s/media/2d0ef79c908ad450db7ddc28eaf7076a02e162af.png'], 'Tele 5': ['48', 'http://ngiss.t-online.de/cm1s/media/05452ad179e25678e50434da167e2f3ede2a9f60.png'], 'TLC': ['383', 'http://ngiss.t-online.de/cm1s/media/bd43973022bc8b5e4e44ecaf07cbeaaca3943fd6.png'], 'TOGGOplus': ['601', 'http://ngiss.t-online.de/cm1s/media/35d704a6beeecc53be277ba5e9342ddca6df5e0a.png'], 'Universal Channel': ['185', 'http://ngiss.t-online.de/cm1s/media/1994bd733a17fbcd32d1d78dc43b28c362776f5b.png'], 'VOX': ['385', 'http://ngiss.t-online.de/cm1s/media/0e5b4d41d518a068a0bef830d64f848b84ac39d1.png'], 'VOXup': ['3930', 'http://ngiss.t-online.de/cm1s/media/7475b5f5fce6df60756901f94904c42d2675c6d9.png'], 'Warner Comedy': ['181', 'http://ngiss.t-online.de/cm1s/media/793f9b574904a15207169109b57f7b52979e9d14.png'], 'Warner Film': ['184', 'http://ngiss.t-online.de/cm1s/media/a4a10078c8d5e31bb59574f9fb4df3ae7d6f975b.png'], 'Warner Serie': ['53', 'http://ngiss.t-online.de/cm1s/media/ac63870aec09e2977583b416e2547620552e6c4d.png'], 'WDR Köln': ['397', 'http://ngiss.t-online.de/cm1s/media/8784546120200060bc84357fcafd0994d648ee40.png'], 'wedo movies': ['5399', 'http://ngiss.t-online.de/cm1s/media/f45a2a145e9188a561e5cbf4e6e77a48e2388fd3.png'], 'Welt': ['375', 'http://ngiss.t-online.de/cm1s/media/949412402d4f2ba8cf1b63ebed3223b6c652765d.png'], 'Welt der Wunder': ['60', 'http://ngiss.t-online.de/cm1s/media/629f72770f72b4f816843f063e0281d9b3d355d9.png'], 'wetter.com TV': ['571', 'http://ngiss.t-online.de/cm1s/media/18ebe2c3ee90c1060da7a5498d2f7e846321271b.png'], 'ZDF': ['408', 'http://ngiss.t-online.de/cm1s/media/35d71e6d09f3551cb4053da8487b3028cf9339cd.png'], 'ZDFinfokanal': ['378', 'http://ngiss.t-online.de/cm1s/media/60641d1e04421f17dd4369382a389b0d7599b736.png'], 'ZDF neo': ['391', 'http://ngiss.t-online.de/cm1s/media/9f4bcfe2464370144428eeac56b55f1cfb061109.png']}
    if int(utils.addon.getSetting("epg_provider")) == 1:
        epg_data = {'1-2-3.tv': ['123TV', 'http://live.tvspielfilm.de/static/images/channels/large/123TV.png'], '13th Street': ['13TH', 'http://live.tvspielfilm.de/static/images/channels/large/13TH.png'], '3sat': ['3SAT', 'http://live.tvspielfilm.de/static/images/channels/large/3SAT.png'], 'Animal Planet': ['APLAN', 'http://live.tvspielfilm.de/static/images/channels/large/APLAN.png'], 'Anixe HD': ['ANIXE', 'http://live.tvspielfilm.de/static/images/channels/large/ANIXE.png'], 'ARD-alpha': ['ALPHA', 'http://live.tvspielfilm.de/static/images/channels/large/ALPHA.png'], 'arte': ['ARTE', 'http://live.tvspielfilm.de/static/images/channels/large/ARTE.png'], 'Auto Motor und Sport': ['AMS', 'http://live.tvspielfilm.de/static/images/channels/large/AMS.png'], 'AXN': ['AXN', 'http://live.tvspielfilm.de/static/images/channels/large/AXN.png'], 'Bibel TV': ['BIBEL', 'http://live.tvspielfilm.de/static/images/channels/large/BIBEL.png'], 'BR': ['BR', 'http://live.tvspielfilm.de/static/images/channels/large/BR.png'], 'Cartoon Network': ['C-NET', 'http://live.tvspielfilm.de/static/images/channels/large/C-NET.png'], 'Comedy Central': ['CC', 'http://live.tvspielfilm.de/static/images/channels/large/CC.png'], 'Crime + Investigation': ['CRIN', 'http://live.tvspielfilm.de/static/images/channels/large/CRIN.png'], 'Spiegel TV Wissen': ['SPTVW', 'http://live.tvspielfilm.de/static/images/channels/large/SPTVW.png'], 'Das Erste': ['ARD', 'http://live.tvspielfilm.de/static/images/channels/large/ARD.png'], 'DAZN 1': ['DAZN', 'http://live.tvspielfilm.de/static/images/channels/large/DAZN.png'], 'Deluxe Music': ['DMC', 'http://live.tvspielfilm.de/static/images/channels/large/DMC.png'], 'Deutsches Musik Fernsehen': ['DMF', 'http://live.tvspielfilm.de/static/images/channels/large/DMF.png'], 'Discovery Channel': ['HDDIS', 'http://live.tvspielfilm.de/static/images/channels/large/HDDIS.png'], 'Disney Channel': ['DISNE', 'http://live.tvspielfilm.de/static/images/channels/large/DISNE.png'], 'DMAX': ['DMAX', 'http://live.tvspielfilm.de/static/images/channels/large/DMAX.png'], 'Eurosport 1': ['EURO', 'http://live.tvspielfilm.de/static/images/channels/large/EURO.png'], 'Eurosport 2': ['EURO2', 'http://live.tvspielfilm.de/static/images/channels/large/EURO2.png'], 'Heimatkanal': ['HEIMA', 'http://live.tvspielfilm.de/static/images/channels/large/HEIMA.png'], 'History Channel': ['HISHD', 'http://live.tvspielfilm.de/static/images/channels/large/HISHD.png'], 'hr-fernsehen': ['HR', 'http://live.tvspielfilm.de/static/images/channels/large/HR.png'], 'Jukebox': ['JUKE', 'http://live.tvspielfilm.de/static/images/channels/large/JUKE.png'], 'Kabel 1': ['K1', 'http://live.tvspielfilm.de/static/images/channels/large/K1.png'], 'kabel eins classics': ['K1CLA', 'http://live.tvspielfilm.de/static/images/channels/large/K1CLA.png'], 'Kabel Eins Doku': ['K1DOKU', 'http://live.tvspielfilm.de/static/images/channels/large/K1DOKU.png'], 'Kika': ['KIKA', 'http://live.tvspielfilm.de/static/images/channels/large/KIKA.png'], 'Kinowelt': ['KINOW', 'http://live.tvspielfilm.de/static/images/channels/large/KINOW.png'], 'K-TV': ['KTV', 'http://live.tvspielfilm.de/static/images/channels/large/KTV.png'], 'MDR Sachsen': ['MDR', 'http://live.tvspielfilm.de/static/images/channels/large/MDR.png'], 'MotorVision': ['MOVTV', 'http://live.tvspielfilm.de/static/images/channels/large/MOVTV.png'], 'MTV Germany': ['MTV', 'http://live.tvspielfilm.de/static/images/channels/large/MTV.png'], 'N24 Doku': ['N24DOKU', 'http://live.tvspielfilm.de/static/images/channels/large/N24DOKU.png'], 'National Geographic': ['N-GHD', 'http://live.tvspielfilm.de/static/images/channels/large/N-GHD.png'], 'Nat Geo Wild': ['N-GW', 'http://live.tvspielfilm.de/static/images/channels/large/N-GW.png'], 'NDR': ['N3', 'http://live.tvspielfilm.de/static/images/channels/large/N3.png'], 'Nick Junior': ['NICKJ', 'http://live.tvspielfilm.de/static/images/channels/large/NICKJ.png'], 'NickToons': ['NICKT', 'http://live.tvspielfilm.de/static/images/channels/large/NICKT.png'], 'n-tv': ['NTV', 'http://live.tvspielfilm.de/static/images/channels/large/NTV.png'], 'One': ['FES', 'http://live.tvspielfilm.de/static/images/channels/large/FES.png'], 'PHOENIX': ['PHOEN', 'http://live.tvspielfilm.de/static/images/channels/large/PHOEN.png'], 'ProSieben': ['PRO7', 'http://live.tvspielfilm.de/static/images/channels/large/PRO7.png'], 'Pro7 Fun': ['PRO7F', 'http://live.tvspielfilm.de/static/images/channels/large/PRO7F.png'], 'ProSieben Maxx': ['PRO7M', 'http://live.tvspielfilm.de/static/images/channels/large/PRO7M.png'], 'Romance TV': ['ROM', 'http://live.tvspielfilm.de/static/images/channels/large/ROM.png'], 'RTL': ['RTL', 'http://live.tvspielfilm.de/static/images/channels/large/RTL.png'], 'RTL II': ['RTL2', 'http://live.tvspielfilm.de/static/images/channels/large/RTL2.png'], 'RTL Crime': ['RTL-C', 'http://live.tvspielfilm.de/static/images/channels/large/RTL-C.png'], 'RTL Living': ['RTL-L', 'http://live.tvspielfilm.de/static/images/channels/large/RTL-L.png'], 'RTL Nitro': ['RTL-N', 'http://live.tvspielfilm.de/static/images/channels/large/RTL-N.png'], 'RTL Passion': ['PASS', 'http://live.tvspielfilm.de/static/images/channels/large/PASS.png'], 'RTLup': ['RTLPL', 'http://live.tvspielfilm.de/static/images/channels/large/RTLPL.png'], 'Sat 1': ['SAT1', 'http://live.tvspielfilm.de/static/images/channels/large/SAT1.png'], 'Sat.1 emotions': ['SAT1E', 'http://live.tvspielfilm.de/static/images/channels/large/SAT1E.png'], 'Sat1 Gold HD': ['SAT1G', 'http://live.tvspielfilm.de/static/images/channels/large/SAT1G.png'], 'Syfy': ['SCIFI', 'http://live.tvspielfilm.de/static/images/channels/large/SCIFI.png'], 'SIXX': ['SIXX', 'http://live.tvspielfilm.de/static/images/channels/large/SIXX.png'], 'Sky 1': ['SKY1', 'http://live.tvspielfilm.de/static/images/channels/large/SKY1.png'], 'Sky Action': ['SKY-A', 'http://live.tvspielfilm.de/static/images/channels/large/SKY-A.png'], 'Sky Atlantic': ['SKYAT', 'http://live.tvspielfilm.de/static/images/channels/large/SKYAT.png'], 'Sky Sport Bundesliga 1': ['BULI', 'http://live.tvspielfilm.de/static/images/channels/large/BULI.png'], 'Sky Cinema Classics': ['SKY-N', 'http://live.tvspielfilm.de/static/images/channels/large/SKY-N.png'], 'Sky Cinema Family': ['SKY-F', 'http://live.tvspielfilm.de/static/images/channels/large/SKY-F.png'], 'Sky Cinema +1': ['CIN', 'http://live.tvspielfilm.de/static/images/channels/large/CIN.png'], 'Sky Krimi': ['SKY-K', 'http://live.tvspielfilm.de/static/images/channels/large/SKY-K.png'], 'Sky Sport F1': ['SKYF1', 'http://live.tvspielfilm.de/static/images/channels/large/SKYF1.png'], 'Sky Sport News': ['SNHD', 'http://live.tvspielfilm.de/static/images/channels/large/SNHD.png'], 'Sonnenklar': ['SKLAR', 'http://live.tvspielfilm.de/static/images/channels/large/SKLAR.png'], 'Spiegel Geschichte HD': ['SP-GE', 'http://live.tvspielfilm.de/static/images/channels/large/SP-GE.png'], 'Sportdigital': ['SPO-D', 'http://live.tvspielfilm.de/static/images/channels/large/SPO-D.png'], 'SR Fernsehen': ['SF1', 'http://live.tvspielfilm.de/static/images/channels/large/SF1.png'], 'Super RTL': ['SUPER', 'http://live.tvspielfilm.de/static/images/channels/large/SUPER.png'], 'Südwest Fernsehen': ['SWR', 'None'], 'tagesschau24': ['TAG24', 'http://live.tvspielfilm.de/static/images/channels/large/TAG24.png'], 'TLC': ['TLC', 'http://live.tvspielfilm.de/static/images/channels/large/TLC.png'], 'TOGGOplus': ['TOGGO', 'http://live.tvspielfilm.de/static/images/channels/large/TOGGO.png'], 'Universal Channel': ['UNIVE', 'http://live.tvspielfilm.de/static/images/channels/large/UNIVE.png'], 'VOX': ['VOX', 'http://live.tvspielfilm.de/static/images/channels/large/VOX.png'], 'VOXup': ['VOXUP', 'http://live.tvspielfilm.de/static/images/channels/large/VOXUP.png'], 'Warner Comedy': ['TNT-C', 'http://live.tvspielfilm.de/static/images/channels/large/TNT-C.png'], 'Warner Film': ['TNT-F', 'http://live.tvspielfilm.de/static/images/channels/large/TNT-F.png'], 'Warner Serie': ['TNT-S', 'http://live.tvspielfilm.de/static/images/channels/large/TNT-S.png'], 'WDR Köln': ['WDR', 'http://live.tvspielfilm.de/static/images/channels/large/WDR.png'], 'Welt': ['WELT', 'http://live.tvspielfilm.de/static/images/channels/large/WELT.png'], 'Welt der Wunder': ['WDWTV', 'http://live.tvspielfilm.de/static/images/channels/large/WDWTV.png'], 'ZDF': ['ZDF', 'http://live.tvspielfilm.de/static/images/channels/large/ZDF.png'], 'ZDFinfokanal': ['ZINFO', 'http://live.tvspielfilm.de/static/images/channels/large/ZINFO.png'], 'ZDF neo': ['2NEO', 'http://live.tvspielfilm.de/static/images/channels/large/2NEO.png']}
    #for row in cur.execute('SELECT * FROM epgs'):
        #if not row['tid'] == '' and not row['tid'] == None:
            #epg_data[row['display']] = [ str(row['tid']), str(row['tl']) ]
    #xbmc.log('EPG_DATA %s' % str(epg_data), xbmc.LOGINFO)
    return epg_data

def getchannels():
    return get_hls_channels() if utils.addon.getSetting("hls") == "true" else get_ts_channels()

def get_ts_channels():
    try: group = json.loads(utils.addon.getSetting("groups"))
    except: group = choose()
    chanfile = utils.get_cache("chanfile")
    if chanfile: return chanfile
    channels={}
    for c in requests.get(vavoourl, params={"output": "json"}).json():
        if "DE :" in c["name"] or c["group"] in group:
            name = filterout(c["name"])
            if name not in channels: channels[name] = []
            j = []
            j.append(c["name"])
            j.append(c["url"])
            channels[name].append(j)
    utils.set_cache("chanfile", channels)
    return channels

def get_hls_channels():
    global channels
    channels = {}
    try: groups = json.loads(utils.addon.getSetting("groups"))
    except: groups = choose()
    chanfile = utils.get_cache("hlschanfile")
    if chanfile: return chanfile

    def _getchannels(group, cursor=0, germany=False):
        global channels
        _headers={"user-agent":"WATCHED/1.8.3 (android)", "accept": "application/json", "content-type": "application/json; charset=utf-8", "cookie": "lng=", "watched-sig": vavoosigner.getWatchedSig()}
        _data={"adult": True,"cursor": cursor,"filter": {"group": group},"sort": "name"}
        r = requests.post("https://www.oha.to/oha-tv-index/directory.watched", data=json.dumps(_data), headers=_headers).json()
        nextCursor = r.get("nextCursor")
        items = r.get("items")
        for item in items:
            if germany:
                if any(ele in item["name"] for ele in ["DE :", " |D"]):
                    name = filterout(item["name"])
                    if name not in channels: channels[name] = []
                    d = []
                    d.append(item["name"])
                    d.append(item["url"])
                    channels[name].append(d)
            else:
                name = filterout(item["name"])
                if name not in channels: channels[name] = []
                d = []
                d.append(item["name"])
                d.append(item["url"])
                channels[name].append(d)
        if nextCursor: _getchannels(group, nextCursor, germany)

    if "Germany" in groups:
        _getchannels("Balkans", germany=True)

    for group in groups:
        _getchannels(group)

    utils.set_cache("hlschanfile", channels)
    return channels

def choose():
    groups=[]
    for c in requests.get(vavoourl, params={"output": "json"}).json():
        if c["group"] not in groups: groups.append(c["group"])
    groups.sort()
    indicies = utils.selectDialog(groups, "Choose Groups", True)
    group = []
    if indicies:
        for i in indicies: group.append(groups[i])
        utils.addon.setSetting("groups", json.dumps(group))
        return group

def handle_wait(kanal):
    progress = xbmcgui.DialogProgress()
    create = progress.create("Abbrechen zur manuellen Auswahl", "STARTE  : %s" % kanal)
    time_to_wait = int(utils.addon.getSetting("count")) +1
    for secs in range(1, time_to_wait):
        secs_left = time_to_wait - secs
        if utils.PY2:progress.update(int(secs/time_to_wait*100),"STARTE  : %s" % kanal,"Starte Stream in  : %s" % secs_left)
        else:progress.update(int(secs/time_to_wait*100),"STARTE  : %s\nStarte Stream in  : %s" % (kanal, secs_left))
        xbmc.Monitor().waitForAbort(1)
        if (progress.iscanceled()):
            progress.close()
            return False
    progress.close()
    return True

def livePlay(name):
    m, i, title = getchannels()[name], 0, None
    if len(m) > 1:
        if utils.addon.getSetting("auto") == "0":
            # Autoplay - rotieren bei der Stream Auswahl
            # ist wichtig wenn z.B. der erste gelistete Stream nicht funzt
            if utils.addon.getSetting("idn") == name:
                i = int(utils.addon.getSetting("num")) + 1
                if i == len(m): i = 0
            utils.addon.setSetting("idn", name)
            utils.addon.setSetting("num", str(i))
            title = "%s (%s/%s)" % (name, i + 1, len(m))  # wird verwendet für infoLabels
        elif utils.addon.getSetting("auto") == "1":
            if not handle_wait(name):    # Dialog aufrufen
                cap = []
                for i, n in enumerate(m, 1):
                    cap.append(n[0])
                i = utils.selectDialog(cap)
                if i < 0: return
            title = "%s (%s/%s)" %(name, i+1, len(m))  # wird verwendet für infoLabels
        else:
            cap=[]
            for i, n in enumerate(m, 1): cap.append(n[0])
            i = utils.selectDialog(cap)
            if i < 0: return
            title = "%s (%s/%s)" % (name, i + 1, len(m))  # wird verwendet für infoLabels
    n = m[i][1]
    o = xbmcgui.ListItem(name)
    url = resolve_link(n) if utils.addon.getSetting("hls") == "true" else "%s?n=1&b=5&vavoo_auth=%s|User-Agent=VAVOO/2.6" % (n, vavoosigner.getAuthSignature())
    o.setPath(url)
    if ".m3u8" in url:
        o.setMimeType("application/vnd.apple.mpegurl")
        o.setProperty("inputstreamaddon" if utils.PY2 else "inputstream" , "inputstream.adaptive")
        o.setProperty("inputstream.adaptive.manifest_type", "hls")
    elif utils.addon.getSetting("ffmpeg") == "true" and xbmc.getCondVisibility("System.HasAddon(inputstream.ffmpegdirect)"):
        o.setMimeType("video/mp2t")
        o.setProperty("inputstream", "inputstream.ffmpegdirect")
        o.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
        o.setProperty("inputstream.ffmpegdirect.stream_mode", "timeshift")
    o.setProperty("IsPlayable", "true")
    title = title if title else name
    epg = get_epg_data()
    plot = "[B]%s[/B] - Stream %s von %s" % (name, i+1, len(m))
    if con and name in epg:
        cur = con.cursor()
        timestamp = int(time.time())
        cur.execute('SELECT * FROM epg WHERE cid="' + str(epg[name][0]) + '" AND start < "' + str(timestamp) + '" AND end > "' + str(timestamp) + '"')
        data = cur.fetchone()
        if data:
            desc = base64.b64decode(data['title']).decode("utf-8")
            start = datetime.fromtimestamp(int(data['start']))
            end = datetime.fromtimestamp(int(data['end']))
            plot = "[B]Now:[/B] (%s Uhr - %s Uhr) [B]%s[/B]" % (str(start.strftime("%H:%M")), str(end.strftime("%H:%M")), str(desc))
    infoLabels={"title": title, "plot": plot}
    if tagger:
        info_tag = ListItemInfoTag(o, 'video')
        info_tag.set_info(infoLabels)
    else: o.setInfo("Video", infoLabels) # so kann man die Stream Auswahl auch sehen (Info)
    utils.set_resolved(o)
    utils.end()

def channels():
    try: lines = json.loads(utils.addon.getSetting("favs"))
    except: lines=[]
    results = getchannels()
    epg = get_epg_data()
    for name in results:
        name = name.strip()
        index = len(results[name])
        title = name if utils.addon.getSetting("stream_count") == "false" or index == 1 else "%s  (%s)" % (name, index)
        o = xbmcgui.ListItem(name)
        cm = []
        if not name in lines:
            cm.append(("zu TV Favoriten hinzufügen", "RunPlugin(%s?action=addTvFavorit&name=%s)" % (sys.argv[0], name.replace("&", "%26").replace("+", "%2b"))))
            plot = ""
        else:
            plot = "[COLOR gold]TV Favorit[/COLOR]\n" #% name
            cm.append(("von TV Favoriten entfernen", "RunPlugin(%s?action=delTvFavorit&name=%s)" % (sys.argv[0], name.replace("&", "%26").replace("+", "%2b"))))
        cm.append(("Einstellungen", "RunPlugin(%s?action=settings)" % sys.argv[0]))
        if con and name in epg:
            o.setArt({ 'thumb': str(epg[name][1]), 'poster' : str(epg[name][1]), 'icon': str(epg[name][1]), 'fanart': str(epg[name][1]) })
            cur = con.cursor()
            timestamp = int(time.time())
            cur.execute('SELECT * FROM epg WHERE cid="' + str(epg[name][0]) + '" AND start < "' + str(timestamp) + '" AND end > "' + str(timestamp) + '"')
            data = cur.fetchone()
            if data:
                desc = base64.b64decode(data['title']).decode("utf-8")
                #desc = base64.b64decode(data['desc']).decode("utf-8")
                start = datetime.fromtimestamp(int(data['start']))
                end = datetime.fromtimestamp(int(data['end']))
                plot += "[B]Now:[/B]\n(%s Uhr - %s Uhr) [B]%s[/B]\n" % (str(start.strftime("%H:%M")), str(end.strftime("%H:%M")), str(desc))
                #plot += "%s \n" % str(desc)
                cur.execute('SELECT * FROM epg WHERE cid="' + str(epg[name][0]) + '" AND start > "' + str(timestamp) + '"')
                data = cur.fetchone()
                if data:
                    desc = base64.b64decode(data['title']).decode("utf-8")
                    #desc = base64.b64decode(data['desc']).decode("utf-8")
                    start = datetime.fromtimestamp(int(data['start']))
                    end = datetime.fromtimestamp(int(data['end']))
                    plot += "\n[B]Next:[/B]\n(%s Uhr - %s Uhr) [B]%s[/B]\n" % (str(start.strftime("%H:%M")), str(end.strftime("%H:%M")), str(desc))
                    #plot += "%s \n" % str(desc)
        o.addContextMenuItems(cm)
        infoLabels={"title": title, "plot": plot}
        if tagger:
            info_tag = ListItemInfoTag(o, 'video')
            info_tag.set_info(infoLabels)
        else: o.setInfo("Video", infoLabels)
        o.setProperty("IsPlayable", "true")
        utils.add({"name":name}, o)
    utils.sort_method()
    utils.end()

def favchannels():
    try: lines = json.loads(utils.addon.getSetting("favs"))
    except: return
    for name in getchannels():
        if not name in lines: continue
        o = xbmcgui.ListItem(name)
        cm = []
        cm.append(("von TV Favoriten entfernen", "RunPlugin(%s?action=delTvFavorit&name=%s)" % (sys.argv[0], name.replace("&", "%26").replace("+", "%2b"))))
        cm.append(("Einstellungen", "RunPlugin(%s?action=settings)" % sys.argv[0]))
        o.addContextMenuItems(cm)
        infoLabels={"title": name, "plot": "[COLOR gold]Liste der eigene Live Favoriten[/COLOR]"}
        if tagger:
            info_tag = ListItemInfoTag(o, 'video')
            info_tag.set_info(infoLabels)
        else: o.setInfo("Video", infoLabels)
        o.setProperty("IsPlayable", "true")
        utils.add({"name":name}, o)
    utils.sort_method()
    utils.end()

def change_favorit(name, delete=False):
    try: lines = json.loads(utils.addon.getSetting("favs"))
    except: lines= []
    if delete: lines.remove(name)
    else: lines.append(name)
    utils.addon.setSetting("favs", json.dumps(lines))
    if len(lines) == 0: xbmc.executebuiltin("Action(ParentDir)")
    else: xbmc.executebuiltin("Container.Refresh")
