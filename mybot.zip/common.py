
loglevel = 'INFO'     # 'DEBUG' # 'ERROR'

api_id = int()
api_hash = ''
phone_number = ''

utc = 0

ssid = ''
demo = True

min_payout = 69       # Minimal Payout for a pair to trade with it.
mtg_level = 1         # MTG count. 0 = disable MTG
mtg_coefficient = 2.0 # Faktor to increase the amount on MTG's
mtg_dynamic = True    # True: Calculate MTG on Payout each Pairs
mtg_typ = 0           # {0: 'next_candle_same_pair', 1: 'next_signal_same_pair', 2: 'next_signal_any_pair'}
anti_mtg = False      # True: Invert Trade. e.g. First Call, Second Put, Third Call ...
max_trades = 1        # Max simultaneous trades. 0 = unlimited
period = None         # {'M1': '1_min_timeframe', 'M5': '5_min_timeframe'}
pairs_type = 0        # {0: 'All', 1: 'nonOTC', 2: 'OTC'}
pairs = []            # Trade only Pairs you want ...

mtg_levels = [
        [20, 300],
        [40, 600],
        [50, 900],
        [60, 1200],
        [80, 1500],
        [100, 1800],
        [120, 2100],
        [140, 2400],
        [160, 2700],
        [180, 3000],
        [200, 3300],
        [220, 3600],
        [250, 3900],
        [280, 4200],
        [310, 4500],
        [350, 4800],
        [400, 5100],
    ]

