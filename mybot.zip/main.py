import threading, asyncio, bot

if __name__ == "__main__":
    t = threading.Thread(target=bot.trade_manager)
    t.start()
    asyncio.run(bot.main())
